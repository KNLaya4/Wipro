package pack1;

public class lab4 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String firstName="K";
		String lastName="Laya";
		char gender='F';
		int age=23;
		double weight=85.55;
		System.out.println("Person Details:\n");
		System.out.println("FirstName:" + firstName);
		System.out.println("LastName" + lastName);
		System.out.println("Gender:" + gender);
		System.out.println("Age:" + age);
		System.out.println("Weight:" + weight);
				
		
		
				

	}

}
