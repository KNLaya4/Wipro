package pack1;

public class lab5{
    public static void main(String[] args) {
        
        if (args.length == 0) {
            System.out.println("Please provide a number as a command line argument.");
            return;
        }

        
        int number = Integer.parseInt(args[0]);

        
        if (number > 0) {
            System.out.println("The number is positive.");
        } else if (number < 0) {
            System.out.println("The number is negative.");
        } else {
            System.out.println("The number is zero.");
        }
    }
}
	